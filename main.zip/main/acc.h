#ifndef acc_h
#define acc_h
class accclass
{
  public:
    accclass();
    void setup();
    float loop();
};

extern accclass acc;

#endif
