#ifndef BRAKES_H
#define BRAKES_H

class brakeclass
{
  public:
    brakeclass();
    void setup();
    float loop();
};

extern brakeclass brake;

#endif
